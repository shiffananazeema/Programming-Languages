<!--
function getCorrectedYear(year) {
  year = year - 0;
  if (year < 70) return (2000 + year);
  if (year < 1900) return (1900 + year);
  return year;
}
        
var lmod = new Date();
var monthname;
var lmonth = lmod.getMonth();
if (lmonth == 0) monthname = "January";
if (lmonth == 1) monthname = "February";
if (lmonth == 2) monthname = "March";
if (lmonth == 3) monthname = "April";
if (lmonth == 4) monthname = "May";
if (lmonth == 5) monthname = "June";
if (lmonth == 6) monthname = "July";
if (lmonth == 7) monthname = "August";
if (lmonth == 8) monthname = "September";
if (lmonth == 9) monthname = "October";
if (lmonth == 10) monthname = "November";
if (lmonth == 11) monthname = "December";

var yearstr = getCorrectedYear(lmod.getYear());
        
var outstr = monthname + " " + lmod.getDate() + ", " + yearstr;
document.write(outstr);
// -->